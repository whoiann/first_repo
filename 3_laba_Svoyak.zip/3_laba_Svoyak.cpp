//
// Лабораторная работа №3
// Выполняла Свояк Валерия Дмитриевна
// Группа НБИбд-01-20
// Вариант №27
//


#include <iostream>				// Подключили необходимые библиотеки
#include <conio.h>
#include <cstring>

using namespace std;			// Указали стандартное пространство имён ввода вывода

const int defMaxStackSize = 50; // Максимальный размер стека по умолчанию

class Samolet   				// Создали класс "Самолёт"
{    
private:
	string Marka;			 	// Обозначили переменную для марки
	string Model;			 	// Обозначили переменную для модели
	int GodSozd; 				// Обозначили переменную для года создания
	int KolMest; 				// Обозначили переменную для количества мест
	int KolSvobod; 				// Обозначили переменную для количества свободных мест
	
public:
	Samolet(){	GodSozd = KolMest = KolSvobod = 0;	}
	Samolet(int buf){	buf = GodSozd;	}
	
	string getMarka(){	return Marka;	}				// Обозначили геттер для поля Марка
	string getModel(){	return Model;	}				// Обозначили геттер для поля Модель
	int getGodSozd(){	return GodSozd;	}				// Обозначили геттер для поля Год создания
	int getKolMest(){	return KolMest;	}				// Обозначили геттер для поля Количество мест
	int getKolSvobod(){	return KolSvobod;	}			// Обозначили геттер для поля Количество свободных мест
	
	void setMarka(string buf){	Marka = buf;	}		// Обозначили сеттер для поля Марка
	void setModel(string buf){	Model = buf;	}		// Обозначили сеттер для поля Модель
	void setGodSozd(int buf){	GodSozd = buf;	}		// Обозначили сеттер для поля Год создания
	void setKolMest(int buf){	KolMest = buf;	}		// Обозначили сеттер для поля Количество мест
	void setKolSvobod(int buf){	KolSvobod = buf;	}	// Обозначили сеттер для поля Количество свободных мест
	
	void show(){										// Создали метод вывода информации о самолёте
		cout << "  Марка: " << Marka << "  Модель: " << Model; 
		cout << "  Год создания: " << GodSozd << "	Мест: " << KolMest;
		cout << "  Cвободно: " << KolSvobod << endl;
	}
};


template <class DataType>
class StackA {											// Создали родительский класс образа Стека
    public:
    StackA( int maxNumber = defMaxStackSize ); 			// Конструктор
    ~StackA();                                 			// Деструктор
    // Операции манипуляции со стеком
    void push(const DataType &newDataItem);   			// Добавление элемента в стек
    DataType pop();                           			// Удаление элемента из стека
    void clear();                             			// Очистка стека
    // Операции статуса стека
    bool isempty() const;          						// Стек пуст?
    bool isfull() const;           						// Стек заполнен?
    // Вывод одержимого стека
    void show() const;             						// Вывести элементы стека

    private:
    // Поля
    int maxSize,                   						// Максимальное количество элементов в стеке
        top;                       						// Индекс вершины стека
    DataType *dataItems;           						// Массив, содержащий элементы стека
};

template <class DataType>
class Aviacompany : public StackA<DataType>{			// Создали унаследованный от класса Стека класс Авиакомпания
	void show(DataType);

};

//--------------------------------------------------------------------

template <class DataType>
StackA<DataType>::StackA(int maxNumber) : maxSize(maxNumber), top(-1)
// Creates an empty stack.
{
    dataItems = new DataType[maxNumber];
}


template <class DataType>
StackA<DataType>::~StackA()
// Frees the memory used by a stack.
{
    delete[] dataItems;
}

//--------------------------------------------------------------------

template <class DataType>
void StackA<DataType>::push(const DataType& newDataItem)
// Inserts newDataItem onto the top of a stack.
{
    if (isfull()) {
        cout << "*** Операция push(), когда стек полон";
        return;
    }
    dataItems[top+1] = newDataItem;
    top++;
}

//--------------------------------------------------------------------

template <class DataType>
DataType StackA<DataType>::pop()
// Removes the topmost data item from a stack and returns it.
{
    if (isempty()) {
        cout << "Операция pop(), когда стек пуст";
        return (DataType) 0;
    }
    DataType temp = dataItems[top];
    dataItems[top] = 0;
    top--;
    maxSize--;
    return temp;
}

//--------------------------------------------------------------------

template <class DataType>
void StackA<DataType>::clear()
// Removes all the data items from a stack.
{
    top = -1;
}

//--------------------------------------------------------------------

template <class DataType>
bool StackA<DataType>::isempty() const
// Returns true if a stack is empty. Otherwise, returns false.
{
    return top == -1;
}

//--------------------------------------------------------------------

template <class DataType>
bool StackA<DataType>::isfull() const
// Returns true if a stack is full. Otherwise, returns false.
{
    return top == maxSize - 1;
}

//--------------------------------------------------------------------

template <class DataType>
void StackA<DataType>::show() const
{
    if( isempty() ) {
    cout << "Пустой стек." << endl;
    }
    else {
    int j;
    cout << "Вершина -> " << top << endl;
    for ( j = 0 ; j < maxSize ; j++ )
        cout << j << "\t";
    cout << endl;
    for ( j = 0 ; j <= top  ; j++ )
    {
        if( j == top )
        {
            cout << '[' << dataItems[j] << ']'<< "\t"; // Identify top
        }
        else
        {
        cout << dataItems[j] << "\t";
        }
    }
    cout << endl;
    }
    cout << endl;
}



void print_help();


int main()
{
	system("chcp 65001");			// Русификация консоли
	
	Aviacompany<Samolet> st;		// Cоздаём экземпляр класса Авиакомпания
	Samolet samolet;				// Создаём экземпляр класса Самолёт
	
	string bufMarka, bufModel;		// Объявили буферные строки для записи данных в стек
	int bufGod, bufMest, bufSvobod;	// Объявили буферные целочисленные переменные для записи данных в стек
	
	char cmd; 						// Инициализируем команду
	
	
		do{
			cout << endl << "  Начинаем работу в программе : " << endl;							// Реализация интерактивного меню
			cout << "  a - Поместить элемент на вершину стека  " << endl;	
			cout << "  b - Извлечь элемент с вершины стека и вывести его на консоль  " << endl;						
			cout << "  c - Проверка на пустоту   " << endl;
			cout << "  d - Проверка на заполненность " << endl;
			cout << "  e - Вывести стек на экран " << endl;
			cout << "  f - Вывести марку и модель, а также количество занятых мест " << endl;
			cout << "  g - Высадить пассажиров" << endl;
			cout << "  u - Досадить пассажиров" << endl;		
			cout << "  i - Очистить стек" << endl;					
			cout << "  k - Выйти " << endl << endl << "  ";
		    cin >> cmd;			
	switch (cmd)																				// Обработка введённой команды
	{
													
		case 'a':			// Поместить элемент на вершину
			cout << "  Введите марку самолёта  : ";
			cin >> bufMarka;
			samolet.setMarka(bufMarka);
			cout << "  Введите модель самолёта  : ";
			cin >> bufModel;
			samolet.setModel(bufModel);
			cout << "  Введите год создания самолёта  : ";
			cin >> bufGod;
			samolet.setGodSozd(bufGod);
			cout << "  Введите количество мест в самолёте  : ";
			cin >> bufMest;
			samolet.setKolMest(bufMest);
			cout << "  Введите количество свободных мест в самолёте  : ";
			cin >> bufSvobod;
			samolet.setKolSvobod(bufSvobod);
			
			st.push(samolet);
			break;
		case 'b':			// Извлечь из вершины стека и вывести
			st.pop().show();
			break;
		case 'c':			// Проверка на пустоту
			if (st.isempty()){
				cout << "  Список пуст  " << endl;
				break;
			} else {
				cout << "  Список не пуст " << endl;
				break;
			}
		case 'd':			// Проверка на заполненность
			if (st.isfull()){
				cout << "  Список полон  " << endl;
				break;
			} else {
				cout << "  Список не полон " << endl;
				break;
			}
		case 'e':			// Вывод стека на экран
			/*--------------------------------------------------------------------*/
			break;
		case 'f':			// Вывод марки, модели, а также количества занятых мест
			if (st.isempty()){
				cout << "  Список пуст  " << endl;
				break;
			} else {
				cout << "  Марка текущего самолёта: " << bufMarka;
				cout << "  Модель текущего самолёта: " << bufModel;
				cout << "  Количество занятых мест: " << bufMest - bufSvobod;
				break;
		case 'g':{ 			// Высадить пассажиров
			int deletePass = 0;
			int osvobodit = 0;
			cout << "  Сколько пассажиров высадить?" << endl;
			cin >> deletePass;
			if (bufMest - bufSvobod < deletePass || deletePass < 0){
				cout << "  Вы пытаетесь высадить больше пассажиров, чем сейчас присутствует на борту" << endl;
				cout << "  Или вы пытаетесь высадить отрицательное количество пассажиров" << endl;
				break;
			} else{
				osvobodit = deletePass + bufSvobod;
				samolet.setKolSvobod(osvobodit);
				st.pop();
				st.push(samolet);
				cout << " Вы успешно высадили " << deletePass << " пассажиров" << endl;
			}
			break;
		}
		case 'u':{ 			// Досадить пассажиров
			int addPass = 0;
			int dobavit = 0;
			cout << "  Сколько пассажиров досадить?" << endl;
			cin >> addPass;
			if ( bufSvobod < addPass || addPass < 0){
				cout << "  Вы пытаетесь досадить больше пассажиров, чем свободных мест на борту" << endl;
				cout << "  Или вы пытаетесь досадить отрицательное количество пассажиров" << endl;
				break;
			} else{
				dobavit = bufSvobod - addPass;
				st.pop();
				samolet.setKolSvobod(dobavit);
				st.push(samolet);
				cout << " Вы успешно досадили " << addPass << " пассажиров" << endl;
			}
			break;
		}
		case 'i':			// Очистка стека
			if (st.isempty()){
				cout << "  Cписок пуст" << endl;
				break;
			} else {
				st.clear();
				break;
			}
			break;
		case 'k': break;	// Выход
		default : cout << " Вы вышли за пределы возможностей программы " << endl;
			break;		
	}
	}} while (cmd != 'k');

	return 0; 		
};