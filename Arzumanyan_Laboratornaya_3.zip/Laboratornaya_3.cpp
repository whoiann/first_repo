//
//  
//  Лабараторная 3

#include <iostream>
#include <cstring>
using namespace std;
const int maxStackSize = 10;    // максимальный размер стека
template <class Item>
class StackS
{
private:
    Item items[maxStackSize];   // массив для элементов стека
    int top;                    // индекс верхнего элемента
public:
    StackS();
    bool isempty() const;
    bool isfull() const;
    // push() возвращает false, если стек уже полон, иначе true
    bool push(const Item & item);   // добавление элемента в стек
    // pop() возвращает false, если стек уже пуст, иначе true
    bool pop(Item & item);          // извлечение элемента в item
    void show();                    // визуализация стека
    void clear();
};


template <class Item>
StackS<Item>::StackS()    // создать пустой стек
{
    top = 0;
}

template <class Item>
bool StackS<Item>::isempty() const
{
    return top == 0;
}

template <class Item>
bool StackS<Item>::isfull() const
{
    return top == maxStackSize;
}

template <class Item>
bool StackS<Item>::push(const Item & item)
{
    if (top < maxStackSize)
    {
        items[top++] = item;
        return true;
    }
    else
        return false;
}

template <class Item>
bool StackS<Item>::pop(Item & item)
{
    if (top > 0)
    {
        item = items[--top];
        return true;
    }
    else
        return false;
}

template <class Item>
void StackS<Item>::show() {
    if (top==0)
        cout << "  Stek pust";
    else
        for (int i=top-1; i>=0; i--)
            cout << items[i] << " ";
    cout << '\n';
}

template <class DataType>
void StackS<DataType>::clear()
// Removes all the data items from a stack.
{
    top = -1;
}

class Bludo
{
private:
    string nazvanie;
	int ves;
	int stoimost;
	int zakazov;
public:
	Student(int buf);
	Student();
	void setNazvanie(string buf) { nazvanie = buf; }
	void setVes(int buf) { ves = buf; }
	void setStoimost(int buf) { stoimost = buf; }
	
	string getNazvanie() const {	return nazvanie;	}
	int getVes() const {	return ves;	}
	int getStoimost() const {	return stoimost;	}
	
	void ychet(){
		cout << " Skolko bylo zakazov?" << endl;
		cin >> zakazov;
	}
	void prodaji(){		cout << " Bludo prodano na " << stoimost * zakazov << " rub.";	}
	void show(){	cout << "  " << nazvanie << "  " << ves << "	" << stoimost << "	" << zakazov << endl;	}
};

template <class DataType>
class Menu : public StackS<DataType>{
	void show(DataType);

};

int main(){
    Menu<Bludo> mn;
    Bludo bludo;
    string bufNazv;
    int bufVes, bufStoim;
    char cmd;
    
    
        do{
    cout << endl << "  1 - Dobavit' bludo v stek " << endl;
    cout << "  2 - Uchest' kolichestvo zakazov  " << endl;
    cout << "  3 - Vyvesti soobshenie o prodazhah  " << endl;
    cout << "  4 - Izvlech bludo iz steka  " << endl;
    cout << "  5 - Proverka steka na zapolnennost'   " << endl;
    cout << "  6 - Proverka steka na pustotu " << endl;
    cout << "  7 - Vyvesti stek na ekran " << endl;
    cout << "  8 - Ochistit' stek " << endl;
    cout << "  0 - Vykhod " << endl << endl << "  ";
    cin >> cmd;
    switch (cmd)
    {
                                                    
        case '1':
            cout << "  Vvedite nazvanie  : ";
            cin >> bufNazv;
			bludo.setNazvanie(bufNazv);
            cout << "  Vvedite ves : ";
            cin >> bufVes; 
			bludo.setVes(bufVes);
            cout << "  Vvedite stoimost : ";
            cin >> bufStoim;
            bludo.setStoimost(bufStoim);
            mn.push(bludo);
            break;
        case '2':
        	mn.pop(bludo);
        	bludo.ychet();
        	bludo.setNazvanie(bufNazv);
        	bludo.setVes(bufVes);
        	bludo.setStoimost(bufStoim);
        	mn.push(bludo);
        	break;
        case '3':
        	bludo.prodaji();
        	break;
        case '4':
        	bludo.show();
            mn.pop(bludo);
            break;
		case '5':
			if (mn.isfull()){
				cout << "  Stek polon" << endl;
				break;
			} else {
				cout << "  Stek ne polon" << endl;
				break;
			}
		case '6':
			if (mn.isempty()){
				cout << "  Stek pust" << endl;
				break;
			} else {
				cout << "  Stek ne pust " << endl;
				break;
			}
        case '7':
        	mn.show();
            break;
        case '8':
            if (mn.isempty()){
				cout << "  Stek pust" << endl;
				break;
			} else {
				mn.clear();
				break;
			}
        case '0': break;
        default : cout << " Vy vyshli za predely vozmozhnostey programmy " << endl;
            break;
    }
    } while (cmd != '0');

    return 0;
};